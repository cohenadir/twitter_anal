import Get_twitter_posts
from db_connect import search
import streamlit as st
# from Get_twitter_posts import get_tweets


st.sidebar.title("check your infulence")

st.sidebar.write("""
by Alon and Adir
""")

infulence = st.sidebar.selectbox("select infulencer", ("Justin Bieber", "CardiB", "Maroon 5", "Lebron James", "Cristiano Ronaldo") )
user = search(infulence)
if user is not None:
    tweets_for_user = Get_twitter_posts.get_tweets(user["twitter_name"])
    for i in tweets_for_user:
        st.write(i)

st.sidebar.write(user)
