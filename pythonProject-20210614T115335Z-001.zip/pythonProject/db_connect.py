import pymongo

from pymongo import mongo_client

client = pymongo.MongoClient("mongodb+srv://alon:alon1@cluster0.6degn.mongodb.net/PythonProj?retryWrites=true&w=majority")
db = client["PythonProj"]
collection = db["users_and_networks"]

def search(name):
    field = collection.find_one({"name": name})
    return field

