import nest_asyncio
import twint as tw


def get_tweets(name):
    # nest_asyncio.apply()
    person = tw.Config()
    person.Username = name
    person.Limit = 5
    person.Store_csv = True
    person.Output = person.Username+".csv"
    person.Lang="en"
    tw.run.Search(person)
    file = open(r'{0}.csv'.format(person.Username), 'r', encoding='utf8')
    rows = file.readlines()
    k = []
    for i in range(4):
        k.append(rows[i])
    file.close()
    file = open(r'{0}.csv'.format(person.Username), 'w', encoding='utf8')
    file.write('')
    file.close()
    return k


